nosso jogo n�o possui menu

o jogador joga utilizando o W para ir para cima e o S para ir para baixo

:)

- Enrico Mandelli
- Rafael Ribeiro